package com.example.soundboard;

import android.media.MediaPlayer;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.TimeUnit;

/*
Name: Sean Williams
Course: CSC 317
Prof: Ben Dicken
    This class will be used to start the sound file "sound_rain_thunder" in the raw resources file
 */
public class RainRunnable implements Runnable{

    AppCompatActivity invokerActivity = null;
    double timeDelay;

    // This method will execute a MediaPlayer which is being called from a Thread elsewhere
    @Override
    public void run() {
        double seconds = timeDelay ;
        long val = (new Double(seconds).longValue());
        TimeUnit time = TimeUnit.SECONDS;
        try {
            time.sleep(val);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        MediaPlayer mediaPlayer = MediaPlayer.create(invokerActivity,R.raw.sound_rain_thunder);
        mediaPlayer.start();
    }

    // Constructor in order to store the activity in which to play the sound
    public RainRunnable(AppCompatActivity activity, double time) {
        invokerActivity = activity;
        timeDelay = time;
    }
}