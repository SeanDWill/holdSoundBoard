package com.example.soundboard;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.concurrent.TimeUnit;
/*
Name: Sean Williams
Course: CSC 317
Prof: Ben Dicken

    This Activity will be used to interact with the UI and handling threads in order to
    play music, set colors and set a delay.
 */
public class MainActivity extends AppCompatActivity {

    // Instance variables used to set time delay and track the current delay switch
    private double timeDelay;
    private int delayButtonCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button setButton = findViewById(R.id.delayButton);
        setButton.setBackgroundColor(Color.GREEN);
        timeDelay = 0;
        delayButtonCount = 0;
    }

    /*
        This method will be called to toggle a delay in the playing of the sounds, this method will
        cycle between the 0,1,2 values in order to keep track of when the button is set to
        0.0,1,5,3.0 second delay to play the desired songs, additionally this will also set the
        ButtonView to the corresponding color Green, Yellow, Red respectively.
     */
    public void delaySound(View v){
        delayButtonCount += 1;
        if (delayButtonCount >=3){
            // Reset count to zero if button was red and count was two
            delayButtonCount = 0;
        }
        if (delayButtonCount == 0){
            timeDelay = 0.0;
            v.setBackgroundColor(Color.GREEN);
        }
        else if (delayButtonCount == 1){
            timeDelay = 1.5;
            v.setBackgroundColor(Color.YELLOW);
        }
        else if (delayButtonCount == 2){
            timeDelay = 3.0;
            v.setBackgroundColor(Color.RED);
        }

    }

    /*
        This method will be called when the "Babbling Brook" button is pressed in the UI
        here there will be a new runnable object being made with a media player inside of it in
        which it will be ran in a new thread after the timeDelay sleeps for however long the
        toggle delay button is set to
     */
    public void brookSound(View v ) throws InterruptedException {
        BrookRunnable brook = new BrookRunnable(this, timeDelay);
        Thread tNew = new Thread(brook);
        tNew.start();

    }

    /*
        This method will be called when the "Soothing Rain" button is pressed in the UI
        here there will be a new runnable object being made with a media player inside of it in
        which it will be ran in a new thread after the timeDelay sleeps for however long the
        toggle delay button is set to
     */
    public void rainSound(View v ) throws InterruptedException {
        RainRunnable thunder = new RainRunnable(this, timeDelay);
        Thread tNew = new Thread(thunder);
        tNew.start();
    }

    /*
        This method will be called when the "Ocean Sounds" button is pressed in the UI
        here there will be a new runnable object being made with a media player inside of it in
        which it will be ran in a new thread after the timeDelay sleeps for however long the
        toggle delay button is set to
     */
    public void oceanSound(View v ) {
        OceanRunnable ocean = new OceanRunnable(this, timeDelay);
        Thread tNew = new Thread(ocean);
        tNew.start();
    }

    /*
        This method will be called when the "Sounds of Summer" button is pressed in the UI
        here there will be a new runnable object being made with a media player inside of it in
        which it will be ran in a new thread after the timeDelay sleeps for however long the
        toggle delay button is set to
     */
    public void summerSound(View v )  {
        SummerRunnable summer = new SummerRunnable(this, timeDelay);
        Thread tNew = new Thread(summer);
        tNew.start();
    }
}
