package com.example.soundboard;

import android.media.MediaPlayer;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.TimeUnit;

/*
Name: Sean Williams
Course: CSC 317
Prof: Ben Dicken
    This class will be used to start the sound file "summer_night" in the raw resources file
 */
public class SummerRunnable implements Runnable{
    AppCompatActivity invokerActivity = null;
    double timeDelay;
    // This method will execute a MediaPlayer which is being called from a Thread elsewhere
    @Override
    public void run() {
        double seconds = timeDelay ;
        long val = (new Double(seconds).longValue());
        TimeUnit time = TimeUnit.SECONDS;
        try {
            time.sleep(val);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        MediaPlayer mediaPlayer = MediaPlayer.create(invokerActivity,R.raw.summer_night);
        mediaPlayer.start();
    }

    // Constructor in order to store the activity in which to play the sound
    public SummerRunnable(AppCompatActivity activity, double time) {
        timeDelay = time;
        invokerActivity = activity;
    }
}